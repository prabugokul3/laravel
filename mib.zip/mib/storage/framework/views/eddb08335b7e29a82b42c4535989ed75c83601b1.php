<!DOCTYPE html>
<html>

<body>
<div class="container">


    <table border = "1">
      <tr>
        <th>ID</th>
        <th>firstname</th>
        <th>lastname</th>
        <th>email</th>
        <th>address</th>
        <th>options</th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($user->id); ?></td>
      <td><?php echo e($user->firstname); ?></td>
      <td><?php echo e($user->lastname); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td><?php echo e($user->address); ?></td>
      <td>
        <a href="<?php echo e('edit'); ?>/<?php echo e($user->id); ?>" class="btn btn-primary">Edit</a>
        <a href="<?php echo e('delete'); ?>/<?php echo e($user->id); ?>" class="btn btn-danger">Delete</a>
    </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\mib\resources\views/view.blade.php ENDPATH**/ ?>