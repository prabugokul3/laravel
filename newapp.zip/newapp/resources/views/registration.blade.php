<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>custom authentication</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
   
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <h4>Registration</h4>
                <hr>
                <form action="register-user" method="POST">
                  @if(Session::has('success'))
                  <div class="alert alert-success">{{Session::get('success')}}</div>
                  @endif(Session::has('fail'))
                  <div class="alert alert">{{Session::get('fail')}}</div>
                  
                  @csrf
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" name="name">
                    <span class="text-danger">@error('name') {{$message}} @enderror</span>
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" name="email">
                    <span class="text-danger">@error('email') {{$message}} @enderror</span>

                  </div>
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input type="text" class="form-control" name="password"> 
                    <span class="text-danger">@error('password') {{$message}} @enderror</span>
                
                  </div>
                  <div class="form-group">
                    <button class="btn btn-block btn-primary" type="submit">Register</button>

                  </div>
                  <a href="login">Already Registered !! Login Here.</a>


                </form>
            </div>
        </div>
    </div>





  </body>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

</html>

